class_name HoverInventory
extends Control

signal slot_is_hovered(slot: ItemSlot)

const TRASH_BIN_SCENE := "uid://ca6c5ffkbovtm"

# Grids used for inventory
@export var grid: GridContainer
@export var columns: int
@export var rows: int
@export var additional_grid: GridContainer
@export var additional_grid_columns: int
@export var additional_grid_rows: int
@export var max_quantity : int = 999
@export var trash_collector: Control
@export var include_trash_bin: bool = false
@export var blacklist: Array[Resource]

var max_slots: int
var inventory: Inventory

# Info Sheet
@onready var info_sheet: PanelContainer = $InfoSheet
@onready var info_name: Label = $InfoSheet/MarginContainer/VBoxContainer/ItemName

func _ready() -> void:
	max_slots = columns*rows
	grid.columns = columns
	inventory = Inventory.new(grid, max_quantity)
	inventory.spawn_slots(Inventory.create_empty_stacks(max_slots), blacklist)
	
	if additional_grid:
		max_slots = additional_grid_columns * additional_grid_rows
		additional_grid.columns = additional_grid_columns
		inventory.spawn_new_slots_to_arbitrary_storage(Inventory.create_empty_stacks(max_slots), additional_grid, blacklist)
	
	if include_trash_bin:
		$VBoxContainer.add_child(preload(TRASH_BIN_SCENE).instantiate())

	# Connections needed for hovering
	inventory.hovering_slot.connect(slot_hovered)
	inventory.mouse_exit_slot.connect(slot_exited)
	info_sheet.visible = false


func get_inventory() -> Array[Resource]:
	var inventory_resources: Array[Resource]
	for item in inventory.item_slots:
		if item.item_holder != null:
			inventory_resources.append(item.item_holder.stack.item)
	return inventory_resources


# Turns info_sheet on if mouse is hovering over slot with stack inside
func slot_hovered(slot: ItemSlot) -> void:
	if Input.is_action_pressed("LMB") or slot.get_item_stack().isEmpty:
		info_sheet.visible = false
		return
	
	update_info_sheet(slot.get_item_stack())
	
	slot_is_hovered.emit(slot)

# Set Info sheet based on item
func update_info_sheet(stack: Stack):
	info_sheet.global_position = get_global_mouse_position() + Vector2(10, 10)
	info_name.text = stack.get_item_name()

	if stack.item is PotionIngredient:
		info_name.text += "\nValue: %d gold" % stack.item.ingredient_price
	elif stack.item is Potion:
		info_name.text += "\nValue: %d gold" % stack.item.base_gold_value

	info_sheet.visible = true


# Turns off info_sheet if mouse moves off a slot
func slot_exited() -> void:
	info_sheet.visible = false
