class_name PopupSubWindow
extends CanvasLayer

@export var sub_viewport: SubViewport
@export var animation_player : AnimationPlayer
@export var black_rect: ColorRect

var player: WorldPlayer
var popup: Node

func _ready() -> void:
	visible = false
	# This may seem overkill but trust the process. You can't miss spell a const
	var ineteractable_objects = get_tree().get_nodes_in_group(Utils.Group.GROUP_INTERACTABLE_OBJECTS)
	
	# This also sucks but a more modular method will be made in the future. This way we don't have to
	# go looking for the player.
	player = get_tree().get_first_node_in_group(Utils.Group.GROUP_PLAYER)
	
	assert(player, "Could not find player. Something is wrong")
	
	if ineteractable_objects.size() <= 0:
		push_warning("Current Scene has no interactable objects. This may be an issue")
		return
	
	for object in ineteractable_objects:
		assert(object is InteractableArea, 
				"A node that isn't an interactable object has been assigned said tag")
		object.connect("interacted", start_display_popup)
		print_debug("connected to node %s" % object)


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("close_minigame") or \
		event.is_action_pressed("open_options_menu"):
		if popup: 
			end_display_popup()
			get_viewport().set_input_as_handled()

func start_display_popup(_scene_to_load: PackedScene) -> void:
	player.accepting_control = false
	popup = _scene_to_load.instantiate()
	
	popup.minigame_won.connect(end_display_popup, ConnectFlags.CONNECT_ONE_SHOT)
	
	sub_viewport.add_child(popup)
	animation_player.play(&"fade_in")

func end_display_popup() -> void:
	animation_player.play_backwards(&"fade_in")
	await animation_player.animation_finished
	# Raise errors but idk what they do
	sub_viewport.remove_child(popup)
	if popup.is_connected("minigame_won", end_display_popup):
		popup.minigame_won.disconnect(end_display_popup)
	
	if popup is Minigame:
		popup.close_minigame()
	
	popup.queue_free()
	
	player.accepting_control = true


func end_specfic_display_popup(temp_popup: Node) -> void:
	sub_viewport.remove_child(temp_popup)
	temp_popup.queue_free()
