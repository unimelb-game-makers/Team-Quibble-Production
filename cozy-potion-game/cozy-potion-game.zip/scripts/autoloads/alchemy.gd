extends Node
# This singleton will most likely be gutted at some point in favor of having its functionality spread out so
# it isn't handling everything related to potion making

# TODO: Have an external script that will convert all ID tags from the spread sheet into consts

enum AttributeID {
	ATTR_HEALING,
	ATTR_MANA,
	ATTR_PARALYSIS,
	ATTR_FOCUS,
	ATTR_STRENGTH,
	ATTR_PERCEPTION,
	ATTR_ENDURANCE,
	ATTR_CHARISMA,
	ATTR_INTELLIGENCE,
	ATTR_AGILITY,
	ATTR_LUCK,
	ATTR_FLAME,
	ATTR_FROST,
	ATTR_SHOCK,
	ATTR_WIND,
	ATTR_EARTH,
	ATTR_WATER,
	ATTR_PURIFICATION,
	ATTR_ANTIDOTE,
	ATTR_SLEEP,
	ATTR_CALMING,
	ATTR_LIGHT,
	ATTR_DARK,
	ATTR_PAIN_RELIEF,
	ATTR_NULL_ATTR,
}

enum IngredientID{
	INGR_APPLE,
	INGR_GINGER,
	INGR_LEMON,
	INGR_CHAMOMILE,
	INGR_PEPPERMINT,
	INGR_GARLIC,
	INGR_HONEY,
	INGR_COFFEE_BEAN,
	INGR_GINSENG,
	INGR_LAVENDER,
	INGR_SAGE,
	INGR_ROSEMARY,
	INGR_CINNAMON,
	INGR_CHILI,
	INGR_SEA_SALT,
	INGR_CLOVER,
	INGR_WILLOW_BARK,
	INGR_POPPY_RESIN,
	INGR_MOONCAP,
	INGR_EMBERROOT,
	INGR_FROSTMINT,
	INGR_SPARK_THISTLE,
	INGR_WHISPER_REED,
	INGR_IRONMOSS,
	INGR_DEEPWATER_KELP,
	INGR_SILVERLEAF,
	INGR_SHADEBERRY,
	INGR_SCHOLARS_MOREL,
	INGR_NIMBLEFERN,
	INGR_VELVET_ROSE,
	INGR_STONECAP,
	INGR_BASILISK_SCALE,
	INGR_SPIDER_LILY,
	INGR_SIREN_PEARL,
	INGR_PHOENIX_ASH,
	INGR_ICE_WYRM_SCALE,
	INGR_STORMGLASS_DUST,
	INGR_SAINTS_BALM,
	INGR_DREAM_ORCHID,
	INGR_VOID_TRUFFLE,
}

enum PotionID {
	POT_HEALING,
	POT_MANA,
	POT_PARALYSIS,
	POT_FOCUS,
	POT_STRENGTH,
	POT_PERCEPTION,
	POT_ENDURANCE,
	POT_CHARISMA,
	POT_INTELLIGENCE,
	POT_AGILITY,
	POT_LUCK,
	POT_FLAME,
	POT_FROST,
	POT_SHOCK,
	POT_WIND,
	POT_EARTH,
	POT_WATER,
	POT_PURIFICATION,
	POT_ANTIDOTE,
	POT_SLEEP,
	POT_CALMING,
	POT_LIGHT,
	POT_DARK,
	POT_PAIN_RELIEF,
}

enum ProcessID {
	PROC_CHOP,
	PROC_GRIND,
	PROC_PRESS,
	PROC_BOIL,
	PROC_DRY,
	PROC_FREEZE,
	PROC_FRY,
	PROC_DISTILL,
} 

enum NeedID {
	NEED_HEAL,
	NEED_MANA,
	NEED_CURE,
	NEED_FOCUS,
	NEED_STRENGTH,
	NEED_PERCEPTION,
	NEED_ENDURANCE,
	NEED_CHARISMA,
	NEED_INTELLIGENCE,
	NEED_AGILITY,
	NEED_LUCK,
	NEED_FLAME,
	NEED_FROST,
	NEED_SHOCK,
	NEED_WIND,
	NEED_EARTH,
	NEED_WATER,
	NEED_PURIFICATION,
	NEED_ANTIDOTE,
	NEED_SLEEP,
	NEED_CALM,
	NEED_LIGHT,
	NEED_DARK,
	NEED_PAIN_RELIEF,
}



const INGREDIENT_JSON: String = "res://resources/json/ingredients.json"
const PROCESSES_JSON: String = "res://resources/json/processes.json"
const POTION_JSON: String = "res://resources/json/potion_list.json"
const INGREDIENT_SPRITES: String = "res://assets/sprites/ingredients/"
const ATTRIBUTE_NEED_MAP_JSON: String = "res://resources/json/attribute_need_map.json"
var PROCESS_SPRITES: Dictionary[Alchemy.ProcessID, Texture2D] = {
	ProcessID.PROC_CHOP: preload("res://assets/sprites/ingredients/chopped_fill_128.png"),
	ProcessID.PROC_GRIND: preload("res://assets/sprites/ingredients/ground_fill_128.png"),
	ProcessID.PROC_PRESS: preload("res://assets/sprites/ingredients/pressed_fill_128.png"),
	ProcessID.PROC_BOIL: preload("res://assets/sprites/ingredients/bottle_liquid_128.png"),
	ProcessID.PROC_DRY: null,
	ProcessID.PROC_FREEZE: null,
	ProcessID.PROC_FRY: null,
	ProcessID.PROC_DISTILL: preload("res://assets/sprites/ingredients/bottle_liquid_128.png"),
}

var sprite_directory: PackedStringArray
var ingredient_list: Array[PotionIngredient] = []
var potion_referance: Array[PotionReference] = []
var process_list: Array[Process] = []
var attribute_to_need_index: Dictionary[AttributeID, NeedID]

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	read_ingredient_data()
	read_potion_data()
	read_attribute_need_map()
	read_processes()
	# brew_potion([ingredient_list[IngredientID.INGR_APPLE], 
	# 			ingredient_list[IngredientID.INGR_GINSENG], 
	# 			ingredient_list[IngredientID.INGR_HONEY]])

# This should only run once
func read_ingredient_data() -> void:
	var json_data: JSON = Utils.get_json(INGREDIENT_JSON)

	ingredient_list.resize(IngredientID.size())
	sprite_directory = DirAccess.get_files_at(INGREDIENT_SPRITES)
	var index := 0
	var start = Time.get_ticks_msec()
	for ingredient in json_data.data:
		var temp_ingredient := PotionIngredient.new()
		temp_ingredient.ingredient_name = ingredient["INGR_NAME"]

		# Used to index an enum with a string
		temp_ingredient.ingredient_id = IngredientID.keys().find(ingredient["INGR_ID"]) as IngredientID
		
		temp_ingredient.ingredient_price = ingredient["BASE_GOLD_VALUE"]
		if ingredient["PURCHASABLE"] == "TRUE":
			temp_ingredient.purchaseable = true
		
		for process in ingredient["COMPATIBLE_PROCESS_ID"].split(", "):
			temp_ingredient.valid_process_methods.append(ProcessID.keys().find(process))

		for attribute in AttributeID.values():
			if attribute == AttributeID.ATTR_NULL_ATTR:
				continue
			temp_ingredient.attributes.set(attribute, int(ingredient[AttributeID.keys()[attribute]]))
		
		temp_ingredient.ingredient_color = Color(ingredient["COLOUR_HEX"])
		temp_ingredient.ingredient_sprite = get_sprite(IngredientID.keys()[temp_ingredient.ingredient_id])

		ingredient_list[index] = temp_ingredient
		index += 1
	var end = Time.get_ticks_msec()
	print_debug((end-start)/1000000.0)

func read_potion_data() -> void:
	var json_data: JSON = Utils.get_json(POTION_JSON)

	potion_referance.resize(PotionID.size())

	for potion in json_data.data:
		var temp_potion := PotionReference.new()

		# There's prob a better way to do this lol
		temp_potion.potion_id = PotionID.keys().find(potion["POT_ID"]) as PotionID
		temp_potion.potion_name = potion["POT_NAME"]
		temp_potion.potion_color = Color(potion["COLOUR_HEX"])
		temp_potion.potion_attribute = AttributeID.keys().find(potion["ATTR_ID"]) as AttributeID
		temp_potion.potion_attribute_name = potion["PRIMARY_ATTRIBUTE"]
		temp_potion.potion_need_id = potion["NEED_ID"]

		potion_referance[temp_potion.potion_id] = temp_potion

func read_attribute_need_map() -> void:
	var json_data: JSON = Utils.get_json(ATTRIBUTE_NEED_MAP_JSON)
	
	for attribute in json_data.data:
		var attr_id = AttributeID.keys().find(attribute["VALID_ATTR_TO_SOLVE_PROBLEM"]) as AttributeID
		var need_id = NeedID.keys().find(attribute["NEEDS_ID"]) as NeedID
		attribute_to_need_index[attr_id] = need_id
		

func read_processes() -> void:
	var json_data: JSON = Utils.get_json(PROCESSES_JSON)
	
	for process in json_data.data:
		var process_resource: Process = Process.new()
		process_resource.name = process["EQUIPMENT_NAME"]
		process_resource.description = process["DESCRIPTION"]
		process_resource.tooltip = process["TOOLTIP"]
		process_resource.id = ProcessID.keys().find(process["PROCESS_ID"]) as Alchemy.ProcessID
		process_resource.texture = PROCESS_SPRITES[process_resource.id]
		for attribute in process:
			var id = AttributeID.keys().find(attribute)
			if id < 0:
				continue
			process_resource.attribute_changes[id] = process[attribute]
	
		process_list.append(process_resource)

func brew_potion(_ingredient_list: Array[PotionIngredient]) -> Potion:
	var _attributes := sum_attributes(_ingredient_list)
	
	var potion := Potion.new()
	potion.constructor(_attributes, _ingredient_list)
	
	return potion

func sum_attributes(_ingredient_list: Array) -> Dictionary[Alchemy.AttributeID, int]:
	var _attributes: Dictionary[Alchemy.AttributeID, int] = {}

	for ingredient in _ingredient_list:
		for attribute in ingredient.attributes:
			_attributes[attribute] = _attributes.get(attribute, 0) + ingredient.attributes[attribute]

	return _attributes


const MISSING_IMAGE = preload("uid://dexko6nfrs6tc")

# This sucks and should be replaced
func get_sprite(_name: String) -> Resource:
	_name = _name.replace("INGR_", "")
	for index in range(sprite_directory.size()):
		var sprite = sprite_directory[index].to_camel_case().to_lower()
		if sprite.contains(_name.to_camel_case().to_lower()):
			var sprite_path = INGREDIENT_SPRITES+sprite_directory[index]
			return ResourceLoader.load(sprite_path.rstrip(".import"))

	print_debug(_name.to_camel_case().to_lower(), " is missing a sprite")
	return MISSING_IMAGE
	
func find_ingredient_by_id(id: IngredientID) -> PotionIngredient:
	for item in ingredient_list:
		if item.ingredient_id == id:
			return item
	return null

func find_process_by_id(id: ProcessID) -> Process:
	for item: Process in process_list:
		if item.id == id:
			return item
	return null	
