extends Node

signal day_complete
signal day_progress_changed
signal day_started
signal tutorial_day_started

#parameters
const DAYS = ["Monday",
"Tuesday",
"Wednesday",
"Thursday",
"Friday",
"Saturday",
"Sunday",
]
#the speed that the day progresses when it has a time to progress towards
const DAY_TICK_RATE_SECONDS: float = 0.15

var current_day: DayResource

var customers_per_day: int = 12
var day_start_hour: int = 12
var day_length: int = 10

#actual variables
var day_progress: float = 0
var days_passed: int = 0
var target_day_progress: float = 0
var visited_forest_this_day: bool = false

#this block is responsible for actually progressing the day towards
#the target day progress and checking if the day is over
func _process(delta: float) -> void:
	var init = day_progress

	day_progress = move_toward(day_progress, target_day_progress, DAY_TICK_RATE_SECONDS * delta)
	if is_equal_approx(DAY_TICK_RATE_SECONDS, 0) or DAY_TICK_RATE_SECONDS < 0:
		day_progress = target_day_progress
	
	#could cause issues at insanely high framerates, but i dont want to redraw 
	#the clock ui every frame in other cases
	if not is_equal_approx(init, day_progress):
		day_progress_changed.emit()
		
	if day_progress >= 1:
		end_day()
		
func day_progress_to_time_string() -> String:
	var hour: int = int(wrap(day_start_hour + day_progress * day_length, 1, 13))
	var minute: int = 0
	#divide by zero
	if day_progress == 0:
		minute = 0
	else:
		minute = ceil(wrap(60 * day_progress * day_length, 0, 60))
	return "%02d.%02d" % [hour, minute]

func days_passed_to_day_string() -> String:
	return DAYS[wrapi(days_passed,0, 7)]

func get_day_progress_increment() -> float:
	return 1.0/customers_per_day
	
func get_current_hour() -> int:
	return int(day_start_hour + day_progress * day_length)
	
##progresses the day by either a custom amount or by an amout dependent on
##number of customers per day. returns true if this ended the day,
##false otherwise
func progress_day(increment: float = 0):
	if not increment:
		increment = get_day_progress_increment()
	target_day_progress += increment
	

func start_day() -> void:
	if days_passed >= 2:
		TutorialDirector.tutorial_day = false

	visited_forest_this_day = TutorialDirector.tutorial_day and days_passed == 0

	day_progress = 0
	target_day_progress = 0

	if TutorialDirector.tutorial_day:
		tutorial_day_started.emit()
	else:
		customers_per_day = 6
		day_started.emit()

	days_passed += 1
	day_progress_changed.emit()
	SaveManager.save_game()

func end_day() -> void:
	day_complete.emit()
	#TODO tie this to some ui input after results screen
	start_day()
