extends Minigame

#signal potion_made

@export var reset_button: Button
@export var make_button: Button
@export var potion_created_container: PanelContainer
@export var potion_created_name_label: Label
@export var potion_created_value_label: Label
@export var inventory: HoverInventory
@export var potion_created_sfx: AudioStream

#signal money_changed(new_value: int)

func _ready() -> void:
	# await potion_brewer.ready

	#reset_button.pressed.connect(reset_potion)
	make_button.pressed.connect(create_potion)
	potion_created_container.gui_input.connect(_on_potion_created_container_gui_input)
	for slot in inventory.inventory.item_slots:
		slot.add_to_group("CauldronSlots")

func create_potion() -> void:
	if inventory.get_inventory().size() == 0:
		minigame_won.emit()
		print_debug("Nothing given")
		return
		
	var potion_recipe : Array[PotionIngredient]
	
	potion_recipe.assign(inventory.get_inventory())
	
	var created_potion := Alchemy.brew_potion(potion_recipe)
	
	for slot in inventory.inventory.item_slots:
		if slot.item_holder:
			slot.item_holder.queue_free()
			slot.item_holder = null
			slot.drag_acceptor.accepting_items = true
	
	potion_created_container.show()
	potion_created_name_label.text = "You made a %s!" % created_potion.potion_name
	potion_created_value_label.text = "(which you can sell for like, $%s.)" % created_potion.base_gold_value
	#get_tree().get_first_node_in_group(Utils.Group.GROUP_PLAYER).potion = created_potion
	player.inventory().blind_add_stack(Stack.new(1, created_potion))
	#reset_potion()
	AudioManager.play_audio(potion_created_sfx)


#func reset_potion() -> void:
	#current_potion.clear()

#well, this is a bit wordy. Descriptive though!
func _on_potion_created_container_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		potion_created_container.hide()
		minigame_won.emit()

func close_minigame() -> void:
	for slot in inventory.inventory.item_slots:
		if slot.item_holder:
			player.inventory().blind_add_stack(slot.get_item_stack())
			slot.item_holder.queue_free()
			slot.item_holder = null
			slot.drag_acceptor.accepting_items = true
