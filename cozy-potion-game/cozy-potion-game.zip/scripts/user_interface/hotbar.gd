class_name Hotbar
extends Container

#a resource that allows for inventory actions
var inventory: Inventory

#this is used when we need to populate the hotbar with empty items
@export var hotbar_item_slot_scene: PackedScene
@export var acceptor: DraggableAcceptorComponent

func _ready() -> void:
	inventory = Inventory.new(self)
	acceptor.accepted_draggable.connect(_on_accept)
	#child_order_changed.connect(_on_children_update)
	create_and_add_test_potion()

func _on_accept(control: Control):
	pass

## Checks to see if we can accept more children
#func _on_children_update() -> void:
	#acceptor.accepting_items = (get_child_count() <= 3)
	#inventory.item_slots.resize(0)
	#for child in get_children():
		#if child is not ItemSlot:
			#continue
		#inventory.item_slots.append(child)

func create_and_add_test_potion() -> void:
	if Utils.get("DEBUG") == null or Utils.get("DEBUG"):
		var ingredients: Array[PotionIngredient]
		ingredients.append(Alchemy.ingredient_list.front())
		var potion: Potion = Potion.new()
		potion = Alchemy.brew_potion(ingredients)
		var stack = Stack.new(1,potion)
		inventory.add_new_slot_from_stack(stack, Control.new())

func repopulate() -> void:
	var new = hotbar_item_slot_scene.instantiate()
	inventory.item_slots.append(new)
	add_child(new)

func get_item_slot_children() -> Array[ItemSlot]:
	var res: Array[ItemSlot]
	for child in get_children():
		if child is ItemSlot:
			res.append(child)
	
	return res
