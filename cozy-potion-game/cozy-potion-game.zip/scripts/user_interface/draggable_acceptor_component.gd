#add as a child of a control that you want to have child draggables
# will push a warning if this node isn't a container.
class_name DraggableAcceptorComponent extends Node

## If this is true, the acceptor will stop accepting draggables once its
## parent has at least max_items number of children.
@export var use_max_items: bool = false
@export var max_items: int = 1
@export var reject_processed: bool = false
var my_control: Control
var accepting_items: bool = true
var blacklist: Array[Resource]

var mouse_intersecting : bool = false

#use this in the control that uses this if you want
signal accepted_draggable(draggable: Control)

func _ready() -> void:
	if not get_parent() is Container:
		push_warning("DraggableAcceptorComponent child of non-container")
	my_control = get_parent()


func _unhandled_input(event: InputEvent) -> void:
	if not event is InputEventMouseMotion:
		# print_debug(1)
		return
	
	if not DraggableComponent.dragged_control:
		# print_debug(2)
		return


	if not my_control.is_visible_in_tree():
		print_debug(3)
		return

	if not accepting_items:
		return

	var intersecting_mouse: bool = \
	my_control.get_global_rect().has_point(my_control.get_global_mouse_position())
	#print_debug(get_viewport().get_mouse_position())

	if intersecting_mouse and DraggableComponent.pending_parent != my_control and accepting_items and not is_full():
		DraggableComponent.pending_parent = my_control
	
	if not intersecting_mouse and DraggableComponent.pending_parent == my_control:
		DraggableComponent.pending_parent == null

func is_full() -> bool:
	if not use_max_items:
		return false
		
	var child_count: int = get_accepted_controls().size()
	return child_count > max_items - 1

## Returns a list of the controls that are siblings to this.
## that is, mostl likely the accepted controls
func get_accepted_controls() -> Array[Control]:
	var res: Array[Control]
	for child in my_control.get_children():
		if child is Control:
			res.append(child)
	return res

#hack. Please let me be done with this
func emit_accepted(draggable: Control):
	accepted_draggable.emit(draggable)
