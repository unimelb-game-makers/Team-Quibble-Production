## add as child of a ui element that you want to be draggable
class_name DraggableComponent extends Node
#this code and the coupled DraggableAcceptor make liberal use of get_parent()
#which is generally bad when overused but there is no other oppurtunity

#if you encounter bugs to do with positioning while dragging, consider
#changing this code to use offset_transform

#use these in the control that uses this component if you want
#functionality when dragging or dropping
signal draggable_dropped
signal draggable_accepted
signal draggable_picked_up
signal drag_request_pick_up

static var dragged_control: Control
static var pending_parent: Control

@export var requests_consent: bool

var previous_parent: Control
var item_resource: Resource # In order to check blacklist
var being_dragged: bool = false
var my_control: Control

static func get_draggable_component(node: Node) -> DraggableComponent:
	for child in node.get_children():
		if child is DraggableComponent:
			return child
	
	return null

static func get_acceptor(node: Node) -> DraggableAcceptorComponent:
	for child in node.get_children():
		if child is DraggableAcceptorComponent:
			return child
	
	return null

func _ready() -> void:
	assert(get_parent() is Control, "draggable component not child of control")
	my_control = get_parent()


func _process(_delta: float) -> void:
	if dragged_control == my_control:
		move_to_mouse()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_released("LMB"):
		being_dragged = false
		my_control.top_level = false
		if dragged_control == my_control:
			dragged_control = null
			#if we don't have a parent waiting to pick up,
			#return to previous owner
			if not pending_parent or pending_parent == my_control.get_parent():
				return_to_previous()
			else:
				parent_to_acceptor()
	
	if !event.is_action_pressed("LMB"):
		return

	if !my_control.get_global_rect().has_point(my_control.get_global_mouse_position()):
		return

	if dragged_control:
		return

	assign_to_mouse()


func assign_to_mouse() -> void:
	draggable_picked_up.emit()
	dragged_control = my_control
	previous_parent = my_control.get_parent()
	my_control.top_level = true
	being_dragged = true

func move_to_mouse() -> void:
	my_control.global_position = my_control.get_global_mouse_position() - my_control.get_global_rect().size/2

# Called when dragged to ensure returns to orignal owner
func return_to_previous() -> void:
	draggable_dropped.emit()
	being_dragged = false
	my_control.reparent(previous_parent)
	my_control.position = Vector2.ZERO
	if previous_parent is Container:
		previous_parent.queue_sort()

func parent_to_acceptor() -> void:
	print("From: ", previous_parent.name)
	print("To: ", pending_parent.name if pending_parent else "None")
	if not pending_parent:
		return_to_previous()
		return

	if check_blacklist():
		print_debug("item blocked by blacklist")
		return_to_previous()
		return
		
	my_control.reparent(pending_parent)
	draggable_accepted.emit()
	
	if get_acceptor(pending_parent):
		get_acceptor(pending_parent).emit_accepted(my_control)
	pending_parent = null

func check_blacklist() -> bool:
	var acceptor = get_acceptor(pending_parent)

	if item_resource is PotionIngredient:
		if acceptor and acceptor.reject_processed and not item_resource.process_applied.is_empty():
			return true

		if pending_parent is ItemSlot and pending_parent.is_in_group("CauldronSlots"):
			if item_resource.process_applied.is_empty():
				return true

	if pending_parent is ItemSlot:
		return pending_parent.is_item_blacklist(item_resource)

	return false
