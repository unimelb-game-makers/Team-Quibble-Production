class_name CustomerManager extends Node

@export var customer_anim_player: AnimationPlayer
@export var customer_world: CustomerWorld
@export var dialogue_resource: DialogueResource
@export var acceptor_dialogue_balloon: PackedScene
@export var speech_bubble_dialogue_balloon: PackedScene
##maps customer ids to their models
@export var customer_models: Dictionary[Customer.CustomerID, PackedScene]
@export var customer_model_offset: Vector3

var customer_interactable: Interactable
static var customer_queue: Array[Customer]
var customer_queue_needs_list: Array[Alchemy.NeedID]
var can_force_potion_to_customer: bool = false
static var returning_from_forest: bool = false

var primary_request_dialogue: DialogueResource
var secondary_request_dialogue: DialogueResource

const THANK_YOU_LINES: Array[String] = [
	"Yeah, that's exactly what I needed. Thanks!",
	"Oh, wonderful! Thank you so much!",
	"Perfect! This should help a lot.",
	"Just what I was looking for!",
	"You're a lifesaver. Thank you!",
	"Excellent! I'll be back if I need another."
]

func _ready() -> void:
	assert(customer_world, "Customer Manager wasn't assigned a customer")
	customer_interactable = customer_world.interactable
	customer_tests()
	DialogueManager.dialogue_started.connect(func(idk = null): can_force_potion_to_customer = true)
	DialogueManager.dialogue_ended.connect(func(idk = null): can_force_potion_to_customer = false)
	customer_interactable.interacted.connect(_on_customer_interact)
	TimeCycle.day_started.connect(_on_day_started)
	TimeCycle.tutorial_day_started.connect(_on_tutorial_day_started)
	var crack
	DevTools.forced_customer_leave.connect(buy_potion.bind(crack))
	
	await get_tree().process_frame
	if not customer_queue.is_empty():
		send_customer()
	returning_from_forest = false

func add_model_to_customer(customer: CustomerWorld, id: Customer.CustomerID) -> void:
	var model_scene = customer_models.get(id)
	if not model_scene:
		return
	
	for child in customer.get_children():
		if not child is Interactable:
			child.queue_free()
			
	var model = model_scene.instantiate()
	customer.add_child(model)
	model.position += customer_model_offset
	model.scale *= 1.2

func _on_day_started() -> void:
	#this await is so that the news manager, which generates
	#news at the start of the day, has time to do that
	#before we need to use it here
	await get_tree().create_timer(1).timeout
	generate_customer_queue()
	send_customer()

func _on_tutorial_day_started() -> void:
	await get_tree().create_timer(1).timeout
	generate_tutorial_customers()
	send_customer()

#generates some number of customers to be drawn from during the day
func generate_customer_queue() -> void:
	customer_queue.clear()
	var customer_needs_list: Dictionary[Alchemy.NeedID, int]
	
	for i in range(TimeCycle.customers_per_day):
		customer_queue.append(Customer.generate_customer())

	for customer in customer_queue:
		customer_needs_list[customer.primary_need] = 0
		if customer.secondary_need > 0:
			customer_needs_list[customer.secondary_need] = 0
	
	customer_queue_needs_list = customer_needs_list.keys()
	
	var time_allotments = generate_customer_time_allotments()
	for i in range(time_allotments.size()):
		customer_queue[i].time_allotment = time_allotments[i]

func generate_customer_time_allotments() -> Array[float]:
	var customer_time_allotments: Array[float]
	#randomly puts a number of points on a line from 0 to 1 equal to the number 
	#of customers per day minus 1. This leaves a number of gaps between points
	#on that number line equal to the number of customers.
	#those gaps are then assigned to the customer time array.
	var points: Array[float]
	for i in range(TimeCycle.customers_per_day-1):
		points.append(randf_range(0, 1))
	
	points.sort()
	customer_time_allotments.append(points.front())
	
	for i in range(1, TimeCycle.customers_per_day-1):
		customer_time_allotments.append(points[i] - points[i-1])
	
	#a little bit of padding is added to this value to ensure that it ends the day
	customer_time_allotments.append(1.1-points.back())
	return customer_time_allotments

func generate_tutorial_customers() -> void:
	customer_queue.clear()
	customer_queue = TutorialDirector.customer_manager_queue

	var time_allotments = generate_customer_time_allotments()
	for i in range(time_allotments.size()):
		customer_queue[i].time_allotment = time_allotments[i]

func send_customer() -> void:
	customer_world.customer = get_next_customer()
	if not customer_world.customer:
		print_debug("customer_world is null!!!")
		return

	primary_request_dialogue = CustomerDialogue.get_potion_request_line(
		Alchemy.attribute_to_need_index.find_key(customer_world.customer.primary_need) as Alchemy.AttributeID,
		customer_world.customer.customer_id
	)

	secondary_request_dialogue = null

	if customer_world.customer.secondary_need >= 0:
		secondary_request_dialogue = CustomerDialogue.get_potion_request_line(
			Alchemy.attribute_to_need_index.find_key(customer_world.customer.secondary_need) as Alchemy.AttributeID,
			customer_world.customer.customer_id
		)

	add_model_to_customer(customer_world, customer_world.customer.customer_id)
	customer_anim_player.play("person_in")
	Utils.corner_needs_list_manager.create_list(customer_world.customer)

func recall_customer() -> void:
	if customer_queue.is_empty():
		return

	customer_queue.pop_front()
	customer_anim_player.play_backwards("person_in")
	await get_tree().create_timer(1).timeout

	if not customer_queue.is_empty():
		send_customer()

func _on_customer_interact() -> void:
	show_acceptor_dialogue()

func show_acceptor_dialogue() -> void:
	var customer = customer_world.customer
	var balloons: Array[SpeechBubbleBalloon]
	# Display dialogue for first request
	var request_dialogue_resource = primary_request_dialogue
	
	var balloon: SpeechBubbleBalloon = DialogueManager.show_dialogue_balloon_scene(acceptor_dialogue_balloon, request_dialogue_resource,"start")
	balloons.append(balloon)
	balloon.set_severity_values(customer.need_severities.front())
	
	# Display dialogue for second request if able, and shift that dialogue's position
	if customer.secondary_need >= 0:
		request_dialogue_resource = secondary_request_dialogue
		balloon = DialogueManager.show_dialogue_balloon_scene(speech_bubble_dialogue_balloon, request_dialogue_resource,"start")
		balloons.append(balloon)
		balloon.flip_x()
		balloon.set_severity_values(customer.need_severities.back())
	
	# Oh my
	var free_all = func(x: Array): for i in x: if is_instance_valid(i): i.queue_free()
	for balloon_enumerated in balloons:
		balloon_enumerated.tree_exited.connect(free_all.bind(balloons))
	
	var acceptor_balloon = balloons.front()
	if acceptor_balloon is ItemAcceptDialogueBalloon:
		var potion_accept_zone: CustomerPotionAcceptZone = acceptor_balloon.potion_accept_zone
		potion_accept_zone.draggable_acceptor_compoment.accepted_draggable.connect(_on_acceptor_accepted)
	else:
		assert(false)

const DYLAN = 1
const RAMSEY = 2

func nightmare(control: Control) -> int:
	if DraggableComponent.get_draggable_component(control) != null:
		return RAMSEY
	
	if ClickableComponent.dragged_control == control:
		return DYLAN
	return 1
		

func _on_acceptor_accepted(control: Control):
	DialogueManager.active_balloon.queue_free()
	
	if not control is ItemHolder:
		if nightmare(control) == RAMSEY:
			DraggableComponent.get_draggable_component(control).return_to_previous()
		else:
			ClickableComponent.the_cunt.stop_dragging()
	
	if control.stack == null:
		return
	
	if control.stack.item == null:
		return

	var item = control.stack.item
	
	if not item is Potion:
		if nightmare(control) == RAMSEY:
			DraggableComponent.get_draggable_component(control).return_to_previous()
		else:
			ClickableComponent.the_cunt.die()
		other_accepted()
		return
	
	if customer_world.customer.check_potion_sufficient(item):
		control.queue_free()
		buy_potion(item)
	else:
		if nightmare(control) == RAMSEY:
			DraggableComponent.get_draggable_component(control).return_to_previous()
		else:
			ClickableComponent.the_cunt.die()
		refuse_potion()

func other_accepted():
	DialogueManager.show_example_dialogue_balloon(dialogue_resource, "not_potion")

func buy_potion(potion: Potion) -> void:
	Utils.corner_needs_list_manager.clear_list()
	var thank_you_dialogue = DialogueManager.create_resource_from_text(
		"~ start\n%s" % THANK_YOU_LINES.pick_random()
	)

	DialogueManager.show_dialogue_balloon_scene(
		speech_bubble_dialogue_balloon,
		thank_you_dialogue,
		"start"
	)
	await DialogueManager.dialogue_ended
	if customer_world.customer.time_allotment:
		TimeCycle.progress_day(customer_world.customer.time_allotment)
	else:
		TimeCycle.progress_day()
	recall_customer()
	
	if potion:
		PersistentInventory.money += get_potion_value(potion, customer_world.customer)

func refuse_potion() -> void:
	DialogueManager.show_dialogue_balloon_scene(speech_bubble_dialogue_balloon,dialogue_resource, "refuse")

#gets the next customer of the day, or else null
func get_next_customer() -> Customer:
	if customer_queue.is_empty():
		return null

	return customer_queue.front()

func get_potion_value(potion: Potion, customer: Customer) -> int:
	var strength_diff = potion.potion_attribute_strength - customer.need_severities.front()
	return max(0, (2 * potion.base_gold_value + 20)/(1 + exp(-0.05*strength_diff)))
	
func customer_tests() -> void:
	var test_customer_1: Customer = Customer.generate_customer(-1)
	assert(test_customer_1.customer_id >= 0, "bad customer 1")
	assert(test_customer_1.needs.size() > 0, "bad customer 1")
	var test_customer_2: Customer = Customer.generate_customer(Customer.CustomerID.NPC_STUDENT)
	assert(test_customer_2.customer_id == Customer.CustomerID.NPC_STUDENT, "bad customer 2")
	assert(test_customer_2.needs.size() > 0, "bad customer 2")
	var test_potion: Potion = Alchemy.brew_potion([Alchemy.ingredient_list.front()])
	get_potion_value(test_potion, test_customer_1)
